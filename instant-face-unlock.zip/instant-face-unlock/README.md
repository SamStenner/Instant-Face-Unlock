# Instant Face Unlock

Description:
Unlocks your phone as soon as face scan is complete

## Installation

Use the repo found at: http://repo.xposed.info/module/com.samstenner.instantunlock

## Usage

Once installed, reboot. That's all!
Note: If the app installs to an SD Card, you need to move it to your internal storage, and THEN do a reboot.

## Other

Twitter: https://twitter.com/SamOfStenner

Donate: https://paypal.me/samstenner
